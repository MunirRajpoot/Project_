class TablesDataTable {

    static init() {
        $('#data-table').DataTable();
    }
}

$(() => { TablesDataTable.init(); });

